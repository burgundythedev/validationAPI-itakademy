<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $path = base_path("database/books.sql"); //recuperer le chemin de authors.sql
        $sql = file_get_contents($path); //recuperation du contenu authors.sql
        DB::unprepared($sql); //execution de la requete sql
    }
}
