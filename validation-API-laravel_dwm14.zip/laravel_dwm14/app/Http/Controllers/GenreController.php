<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Genre;


class GenreController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request)
    {
        $query = $request->query();
       
        if(isset($query['sort'])) {
         
            if ($query['sort'] === "asc") {

                $orderGenre = Genre::orderBy('id', 'asc')->paginate();
                return response()->json($orderGenre, 200);

            } else if ($query['sort'] === "desc") {

                $orderGenre = Genre::orderBy('id', 'desc')->paginate();
                return response()->json($orderGenre, 200); 

            } 
        }
        $genre = Genre::all();    
        return response()->json($genre, 200);

      
    }
    

      /**
     * Search and Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */

    public function search ($name) {
        
        $search = Genre::where("name", "like", "%".$name."%")->get();
        // dd($name);
        return response()->json($search, 200);
    } 

 

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) 
    {

        $newGenre = Genre::addGenre($request->all());
        return response()->json($newenre, 201); 
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id) //modifier les params
    {   
        // dump($id);
        // die;
        $genre = Genre::find($id);
        

        if ($genre) {
           return response()->json($genre, 200);  
        } else {
            return response()->json("Genre Not Found", 404); 
        }
        
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Genre $genre
     * @return \Illuminate\Http\Response
     */


    public function update(Request $request, Genre $genre)
    {   
        // dump($request->name);
        // die;
        $updateGenre = Genre::updateGenre($genre, $request->all()); //recuperation de l'auteur
        return response()->json($genre, 200); //retourne un json
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Genre $genre)
    {
        $genre->delete();

        return response()->json(null, 204);
    }
}
