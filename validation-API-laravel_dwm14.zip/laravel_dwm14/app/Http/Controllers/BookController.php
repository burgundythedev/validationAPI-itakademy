<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Book;
use App\Http\Resources\BookResource;
use App\Http\Resources\BookCollection;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   
        
        $query = $request->query();
       
        if(isset($query['sort'])) {
         
            if ($query['sort'] === "asc") {

                $orderBook = Book::orderBy('id', 'asc')->paginate();
                return response()->json($orderBook, 200);

            } else if ($query['sort'] === "desc") {

                $orderBook = Book::orderBy('id', 'desc')->paginate();
                return response()->json($orderBook, 200); 

            } 
        } 
        
        // else if (isset($query['filter'])) { 
        //     $filter= $query['filter'];
            
        //     $bookFilter = Book::whereHas('genres', function($query) use ($filter){
        //         $query->where('genres.name', "=", $filter);
        //     });
        //     dd($bookFilter);
        //     return new BookCollection($bookFilter->get());
        // }

        $book = Book::all();    
        return response()->json($book, 200);        
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $newBook = Book::addBook($request->all());

        return response()->json($newBook, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {   
        $book = Book::find($id);
        if ($book) {
            return response()->json($book, 200);  
        } else {
            return response()->json("Book Not Found", 404); 
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Book $book)
    {
        $updatedBook =  Book::updateBook($book, $request->all());

        return response()->json($updatedBook, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Book $book)
    {
        $book->delete();

        return response()->json(null , 204);
    }


           /**
     * Filter and Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
}



