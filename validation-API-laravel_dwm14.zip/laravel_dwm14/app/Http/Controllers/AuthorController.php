<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Author; //mettre le chemin que l'on veut vers la donnees
use App\Http\Resources\AuthorResource;
use App\Http\Resources\AuthorCollection;




class AuthorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
    //     $author = Author::all(); 
    // //method recuperation de tous les authors class author/use.author
        
    //     return response()->json($author, 200); 
    // //reponse json deux param 1er les authors/ deuxieme le code http/check pdf cours
        $authorList = Author::paginate();
        return new AuthorCollection($authorList);   
     
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) //creation d'un nouvel autheur
    {

        $newAuthor = Author::addAuthor($request->all());
        return response()->json($author, 201); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id) //modifier les params
    {
        
        $author = Author::find($id);
        if ($author) {
            return new AuthorResource($author);  
        } else {
            return response()->json("Author Not Found", 404); 
        }
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Author $author
     * @return \Illuminate\Http\Response
     */


    public function update(Request $request, Author $author)
    {   
        dump($request->name);
        die;
        $updateAuthor = Author::updateAuthor($author, $request->all()); //recuperation de l'auteur
        return response()->json($author, 200); //retourne un json
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Author $author)
    {
        $author->delete();

        return response()->json('', 204);
    }
}
