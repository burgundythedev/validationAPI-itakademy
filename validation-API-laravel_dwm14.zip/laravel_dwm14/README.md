# Laravel: Crétation D'API: Olivier Bourgogne


Bonjour Vincent,

- Voici mon projet API:

    Tu peux y retrouver les fonctionnalités suivantes:

        - "CRUD" pour les trois classes (BOOKS,GENRE,AUTHOR) 
            avec "code HTTP" correspondant.

        - Une Gestion des "erreurs 404" qui selon la class nous indiquent qu'il ne trouve pas l'information demandée. testable via l'url de l'API

        * Ci-jointe, le lien de ma collection POSTMAN: 
        https://www.getpostman.com/collections/29995a2eb777338ec9af


        Tu peux retrouver la pagination sur la page Author -> (function index ->AuthorController.php); testable via l'url de l'API
            * ainsi que les autres entitées.

        Une Fonction "Sort" sur notre Class "BOOK & GENRE". testable via l'url de l'API

        Ainsi que une Fonction  "Search" dans la class GenreController, testable via l'url de l'API.




Je n'ai pas réussi à faire le "filter" malgré quelques tentatives.

Merci, 

Bonne journée/soirée

Olivier

















































## Récupérer ce projet
Se mettre dans le dossier souhaité, puis utiliser cette commande :
```bash
git clone https://github.com/jperaudon/laravel_dwm14.git .
```
Faire une copie du ```.env.example``` et la nommer ```.env```, puis :
```bash
composer install
php artisan migrate --seed
```


## Exercices

### Exo 1
Créer un Controller : NavController


### Exo 2
- Arriver à ajouter une information dans une vue.
  
### Exo 3
- Ajouter une nouvele page avec un formulaire. Ce formulaire demande votre age. => Formulaire Blade
- Quand on valide le formulaire, on arrive de nouveau sur une nouvelle page, qui affiche 'Tu as [age] ans !'

### Exo 4 : séparer les auteurs de la tables "books".
Vous devrez créer une nouvelle table "author" qui contiendra principalement une colonne "name".
Il faudra ensuite trouver comment relier les tables books et authors.
Sachant que chaque livre n'a qu'un seul auteur, mais que les auteurs peuvent avoir écrit plusieurs livres.
Mettre en place le CRUD des auteurs (update étant optionnel)
Et princialement : faire en sorte que l'affichage actuel redevienne valide ! (les choix des auteurs se feront via des inputs select)
